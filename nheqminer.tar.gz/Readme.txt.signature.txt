{
  "hash": "4032c1ded20314a6c5b00a4d0ac92b2c3c85d11732e5ec6f1921fda635347c8b",
  "signature": "AWobEAABQR/EqIHR/uc7us/M3hGLzzrlfkR8tWXqqJwQodP7qh5sGhBOoTm4ibIpKiGHBzPN1g61h+qYyu12L3LehREGyLbJ",
  "signer": "Verus Coin Foundation Releases@"
}
